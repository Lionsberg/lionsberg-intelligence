# LIØNSBERG Wiki Books

The longer works of the wiki. Each is a book: a body of pages with its own order and its own voice, read from its front page. Each is a [[Work In Progress]].

- [[The Book of LIØNSBERG]]: the long telling. An introduction and fourteen chapters, most of them named as Quests, from Genesis to the Art and Science of the Way. About 500 pages.
- [[The LIØNSBERG Strategy and Plan]]: the strategy and plan of action, in 43 short chapters, with its updates. Last updated August 2026.
- [[The Program Delivery Guide]]: how the work is delivered at scale. It holds the original guide to integrated project delivery, and its application to the Earth.
- [[The Great Game of LIØNSBERG]]: how the Game is played. The rulebook, and a page for each move: [[Form A Cell]], [[Choose A Quest]], [[Share Your Stories]] and [[Pass The Flame]].
- [[Frequently Asked Questions]]: the questions people ask first, each answered on a page of its own.
- [[The LIØNSBERG Book of Meditations]]: more than six hundred short meditations to sit with, one to a page.
- [[The LIØNSBERG Lexicon]]: the words we use, each with a page of its own.

More books are being brought in from the earlier wiki as each is reviewed.
