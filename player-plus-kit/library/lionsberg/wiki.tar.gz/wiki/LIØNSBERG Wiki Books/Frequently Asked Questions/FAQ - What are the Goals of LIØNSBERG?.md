# FAQ - What are the Goals of LIØNSBERG?

LIØNSBERG exists in service to [[The Goal]] of the total integrated wellbeing, development, and right relationship of all generations of life and consciousness. 

It's [[Purpose]] is perpetually renew and regenerate the world towards [[Heaven On Earth]].  

The [[Total Nested Holarchy of Goals]] required to accomplish [[The Goal]] are all included. 

These are mapped against [[The 12 Pillars of LIØNSBERG]] as a [[Work Breakdown Structure]] for organization and collective action. 

The entire philosophy of LIØNSBERG revolves around the reality that nothing is excluded, and We The People are responsible for everything in partnership with [[ØNE]] and [[One Another]].  

See more [[Frequently Asked Questions]]  
