# FAQ - How Does LIØNSBERG Address the Local and Global Challenges We Face Today?

LIØNSBERG addresses the local and global challenges by connecting and empowering people and communities to take action, co-create, and cross-pollinate solutions that work for them, society and for the planet. It provides the framework, tools, and support necessary for individuals and groups to tackle meaningful [[Quests]] as a decentralized [[Team of Teams]] to address issues such as division, inequality, injustice, corruption, insecurity, and social and environmental degradation, while proactively co-creating [[Heaven On Earth]]. 

See more [[Frequently Asked Questions]]  
