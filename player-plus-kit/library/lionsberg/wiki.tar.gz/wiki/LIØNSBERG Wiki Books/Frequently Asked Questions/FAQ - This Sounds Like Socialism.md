# FAQ - This Sounds Like Socialism

The LIØNSBERG System is not socialism. Socialism is a political and economic theory that advocates for the collective ownership and control of the means of production and distribution of goods and services by the government, and for the equal distribution of wealth and income among all members of society. 

While the LIØNSBERG System does prioritize the well-being and prosperity of all members of society, it does not advocate for government ownership of the means of production and distribution. Instead, it advocates for citizen-led impact in society and citizen-led stewardship of resources, guided by principles of truth, love, justice, stewardship and wisdom in service of One and All. This means empowering individuals and communities to take control of their own resources and development, while also working together to create a more just, sustainable, and prosperous world for all.

It is also different from capitalism, which is an economic system based on private ownership of the means of production and the creation of goods and services for profit. The LIØNSBERG System prioritizes the total integrated development and wellbeing of all members of society, not just those who are able to accumulate wealth and profit. It also places a strong emphasis on collective stewardship and the protection of the environment and natural resources, which is not always a priority in a capitalist system fueled by self-interest and competition. 

The LIØNSBERG System is unique, and it is not limited by any existing political or economic theory. It aims to create a new and higher Aim, equidistant from capitalism and socialism, left and right, that is based on principles of love, compassion, and equality for all, and it empowers people and communities to take control of their own development. 

This higher universal and eternal Aim is One with the wisdom, principles, values, and guiding Spirit of people like Jesus, who have encouraged us to seek first the highest overarching and uniting will and intention of God, on earth as it is in heaven. 
