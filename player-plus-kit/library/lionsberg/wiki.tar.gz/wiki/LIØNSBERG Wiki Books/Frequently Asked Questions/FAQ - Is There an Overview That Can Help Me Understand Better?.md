# FAQ - Is There an Overview That Can Help Me Understand Better?

Yes. [[J]] is progressively articulating a series of [[LIØNSBERG Wiki Books]] that provide more structured overviews through a variety of lenses. These books lay out the context, vision, plan and system in structured narrative form. 

Jordan's writing in [[Above The Chaos]] may also be useful and encouraging to you. 

See more [[Frequently Asked Questions]]  
