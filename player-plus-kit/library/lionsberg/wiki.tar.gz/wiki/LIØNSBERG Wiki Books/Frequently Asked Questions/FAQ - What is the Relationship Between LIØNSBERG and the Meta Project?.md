# FAQ - What is the Relationship Between LIØNSBERG and the Meta Project?

Whereas the [[Meta Project]] points to the total set of all things that need to be done by the human species to accomplish [[The Goal]], [[LIØNSBERG]] is what **enables** the [[Higher Order Functional Unity]] required for humanity to actually achieve them. 

See more [[Frequently Asked Questions]]  
