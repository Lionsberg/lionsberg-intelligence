# FAQ - How Does LIØNSBERG Align with my Beliefs and Values?

LIØNSBERG aligns with universal spiritual and philosophical values such as truth, love, justice, stewardship, and wisdom as aspects of the [[Total Nested Holarchy of Values]]. It empowers individuals and groups to take control of their own development while helping one another advance towards a more loving, just, and regenerative society, which aligns with the core values of nearly all religious and philosophical traditions. 

Developed in service to [[ØNE]] and [[All]], it prohibits "state religion" and encourages each individual to humbly learn from One Another and Help One Another Progress towards Right Relationship with the Creator, One Another, and All Creation in accordance with the dictates of their own Spirit and Conscience.  

LIØNSBERG neither imposes any religious or ideological dogma on any Sovereign, nor allows the imposition of any dogma upon it.  

See more [[Frequently Asked Questions]]  
