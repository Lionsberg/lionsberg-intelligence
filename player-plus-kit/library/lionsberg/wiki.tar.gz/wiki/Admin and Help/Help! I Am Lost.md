# Help! I Am Lost

Welcome to the LIØNSBERG Wiki. We know it can be overwhelming, and difficult to learn to navigate. If you ever get lost, come back to this page.

## Getting back

- The [[README|home page]] is the front door. You can start again from there at any time.
- If you followed a link and want to return to where you were, use the back button.

## Good places to begin

- [[The Invitation]] is the page most people are handed first.
- [[LIØNSBERG Core Statements]] says what LIØNSBERG is in a few short pages. Start with [[One Sentence]].
- [[Frequently Asked Questions]] answers the questions most people ask first.
- [[The LIØNSBERG Lexicon]] explains the words we use. If a word on a page is unfamiliar, it is probably there.
- The [[LIØNSBERG Wiki Books]] are the longer, more structured works.

## Finding what you are looking for

- **Search.** Type a word or a phrase into the search box.
- **Follow the links.** Each page links to its neighbours. A link shown in a fainter colour leads to a page that has not been written or brought in yet ([[The Incipient Link]]).
- **See what links here.** In Obsidian, the backlinks pane shows every page that points to the one you are reading.

## Asking a person

You can also ask the one who invited you, or ask in the place where your [[Circle]] gathers.

If something here is wrong, missing or hard to follow, please say so. [[Our Way of Writing Here]] explains how a change is proposed.

Love and respect, and thank you for diving in.
