# Getting the Wiki on Your Computer

The wiki is a folder of plain text files written in Markdown. It lives in a Git repository on a forge that we keep ourselves. With your own copy you can read it with no network, write in it, and offer changes back.

You can do each step below yourself, or ask your agent to do it with you.

## What you need

- **An ID card for the forge.** This is a key that lets the forge know you. You send the public line of your card to a keeper of the forge, who adds you ([[Your ID Card]]).
- **Git**, the tool that keeps the history of every change.
- **A way to read and write Markdown.** We use [Obsidian](https://obsidian.md/). Any text editor will do.

## Get your copy

In a terminal, go to the folder where you keep your work for LIØNSBERG, and clone the wiki:

```
git clone falcon:lionsberg/lionsberg-wiki
```

`falcon` is the short name for the forge that is set up along with your ID card.

## Open it in Obsidian

In Obsidian, choose **Open folder as vault**, and pick the folder that contains `lionsberg-wiki`, one level up from the wiki itself. Other repositories will sit beside the wiki in that folder, and opening it as the vault lets their pages link to each other.

[[Obsidian Tips and Tricks]] has settings worth checking.

## Each time you work

Pull when you begin, so that your copy has everyone's latest changes:

```
git pull
```

When you finish, save your changes with a short message that says what you did, and push them:

```
git status
git add .
git commit -m "what changed, in a few words"
git push
```

`git status` shows what you changed. To save one file and leave the rest, name it: `git add "Page Name.md"`.

If Git reports a conflict when you pull, stop there and ask for help before going further.

## Offering a change to the shared body of work

A change to the shared body of work goes in by proposal ([[Our Way of Writing Here]]). Put it on a work branch, and someone else merges it into `main`.

Name the branch with your initials, a few words for the work, and the date:

```
git checkout -b ab-quick-start-typos-2026-11-21
git push --set-upstream origin ab-quick-start-typos-2026-11-21
```

Then tell a steward the branch is there. If the forge refuses your push, tell a steward what you changed and they will help you send it.

## Good to know

- The main branch is named `main`.
- If the forge refuses you, check your ID card. If you gave it a time limit, it may have locked. Unlock it and try again.
