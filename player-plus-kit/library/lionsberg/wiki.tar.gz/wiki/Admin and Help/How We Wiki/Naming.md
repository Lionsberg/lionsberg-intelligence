# Naming

[[Chunking]] breaks information into pieces of [[Modular Content]]. Naming is how we find a piece and refer to it.

Naming happens mostly at the level of the page. It also happens at the level of headers.

As a community, we want to converge on the same name for the same concept. One name for one concept lets us keep merging and chunking our writing into a shared language ([[The LIØNSBERG Lexicon]]).

A concept page is named in the singular: [[Cell]], [[Quest]], [[Story]]. To write the plural, pipe the link: `[[Cell|Cells]]`. A name whose plural is the concept itself keeps its own form, such as [[The First Three Percent]] or [[The 300]].

Links reach a page by its name. What you write there is what readers of those links will find. Before taking a name for a new page, see how the wiki already uses it ([[Semantic Capture]]).
