# Our Way of Writing Here

Here we describe our way of writing on this wiki website ([[Why We Say Wiki Website Instead of Wiki]]).

## Writing as a team

We are learning to write as a team, so that the wiki holds both our individual voices and our shared [[Current Best Understanding]]. Many hands write here: people, and the agents who work beside them.

LIØNSBERG is being co-created as one coherent [[LIØNSBERG System|System]]. Its words and concepts matter the way they matter in the plans and specifications for a building or a [[New Civilization]]. If someone changes a definition without understanding how the parts fit together, the change can confuse other co-creators or weaken the whole. So different parts of the wiki are written and edited in different ways.

## Three kinds of writing

**The shared body of work** speaks as "we". It holds the core statements, the plans and specifications, the guides and the pages that define our words. Each piece is made to work with the others as part of one whole, so it is edited with care, by proposal (see below).

**[[LIØNSBERG Wiki Books|Wiki Books]]** are longer, more formal bodies of work. A book speaks in the voice of its author or authors, and it does not have to match the shared understanding at every point. To co-author or edit someone's book, ask for their consent first ([[LIØNSBERG Wiki Book]]).

What is published in the wiki is decided by its [[Stewards|stewards]], so that the whole keeps its integrity.

## Proposing a change

Anyone may propose an improvement to any part of the shared body of work at any time via a [[Pull Request]] or [[Proposal]]. The aim is for it to get [[A Little Better Every Day|a little better every day]].

The steward function is meant to be held by several people, so that no one person becomes a bottleneck or a single point of failure.

Text drafted by an agent is a proposal like any other. It joins the shared body of work when a person has read it and taken it up.

## Before you edit the shared body of work

Read the core material first, enough to be able to speak in its voice ([[The LIØNSBERG Voice]]). Ask questions as you go, privately if you prefer, and fold the answers back into the pages so the next reader does not have to ask.

Before you create or rewrite a page for a concept, find out what the wiki already holds on it: the pages that link to that name, and the places where the idea lives under other names ([[Semantic Capture]]).

## How we speak

- We write as "we", in the present tense, and we do not attach an idea to a person's name. A view that belongs to one person goes in a Journal or a Book.
- We say plainly what we hold, and we say just as plainly where [[We Do Not Know]]. What we write is our [[Current Best Understanding]].
- A page carries the present sense of its subject. The story of how the page was made lives in the wiki's Git history.
- We spell our own names as they are: LIØNSBERG, ØNE.

## What stays off the page

- A person's contact details, family particulars or private circumstances.
- Who said what in a room, and what was said there in confidence ([[Chatham House Rule]]).
- An agent's working notes, review marks and instructions.

## Making pages

- Make the first line of each page a level 1 header that matches the page's file name. The first line of this page is `# Our Way of Writing Here`.
- Leave these characters out of page names, because file systems and links stumble on them: `/ \ : * ? " < > | # ^ [ ]`.
- A page is a place you would want to land from a link: a concept, or a short chapter.
- A page may start as a line or two. When it is fully grown it usually holds at least a couple of paragraphs.
- Name a concept in the singular ([[Naming]]).

## Simple Markdown

- Use a dash for bullet lists.
- Use underscores for italic and asterisks for bold: `_italic_` and `**bold**`.
- Leave a blank line between different kinds of elements, such as a header and a list.
- In verse, end each line with two spaces so that the lines do not run together ([[The LIØNSBERG Voice]] says where else).

## Links

- A wiki link: `[[Linking]]` makes [[Linking]].
- A wiki link with different words showing: `[[Circle|Circles]]` makes [[Circle|Circles]].
- A link to the web: `[the words to show](https://www.example.com/)`.
- A bare web address goes in angle brackets: `<https://www.example.com/>`.
- To show wiki text exactly as typed, wrap it in backticks. For several lines, put three backticks on a line above them and three on a line below.

We do not use hashtags. We use links ([[Linking]]).
