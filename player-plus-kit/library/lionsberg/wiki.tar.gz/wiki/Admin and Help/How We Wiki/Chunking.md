# Chunking

Chunking is taking undifferentiated information and turning it into chunks of [[Modular Content]]. You are chunking each time you decide

- what goes on one page and what goes on another
- what goes under a header
- what level a header has
- what becomes a bullet list

One long document with no differentiation is a poor fit for a wiki. How you chunk it decides the rough shape of the network of pages.

A wiki is very good at rechunking. When a page has grown into two ideas, split it. When two pages turn out to be one idea, join them.

In a visual map, space is what sets one item apart from another. In a wiki, pages, headers and lists do that work.

In Obsidian, the Outline pane shows a page's headers as its structure, and you can jump from one part of the page to another.

Chunking gives us [[Modular Content]]: pieces small enough to name, link and reuse ([[Naming]], [[Linking]]).
