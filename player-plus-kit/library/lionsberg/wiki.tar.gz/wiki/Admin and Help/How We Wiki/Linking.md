# Linking

In a wiki, we make links from one page to another. Each link also creates a backlink: the other page knows it has been pointed to, and can show you every page that points to it.

We also link out to the web, and the web can link in to us.

In this wiki, double square brackets around words make a link. Typing `Linking` makes Linking.

## How we link

- **Link generously.** Link each significant term the first time it carries weight in a passage, whether or not its page exists yet ([[The Incipient Link]]).
- **Link to the concept.** In running prose, link an idea to its own page, and leave chapter numbers and section addresses to tables of contents ([[Link to the Concept, Not the Coordinate]]).
- **Use links where you would have used a tag.** We do not use hashtags. Make a link to a page for the concept ([[Everything Is A Link]]).
- **Pipe a link when the sentence needs different words.** `[[Circle|Circles]]` shows as [[Circle|Circles]].

[[Our Way of Writing Here]] has the rest of the link forms.
