# The Incipient Link

An incipient link is a link to a page that does not exist yet.

Make one whenever a concept deserves a page. Type its name in double square brackets and keep writing, without breaking your train of thought. The link holds the place. When someone follows it and begins to write, the page exists.

An incipient link is as much a part of the wiki as a page is. It records that a concept matters here and is waiting to be written. Each page that already names the concept connects to the new page the moment it is born.

Before you write the page an incipient link points to, read the pages that already link to that name, and read what the wiki holds on the idea under other names. The page you write becomes the meaning of each of those links ([[Semantic Capture]]).
