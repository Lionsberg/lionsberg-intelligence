# The LIØNSBERG Voice

_The voice in which the shared body of work speaks, and the measure each paragraph is read against._

This voice is for the teaching pages of the shared body of work. Help pages are written plainly.

## The posture

The voice of a wise elder at the fire. It carries the gravity of a text meant to last and the clarity of a working manual. It is read aloud in [[Circle|Circles]].

## Say what we hold, plainly

Open with the thing itself. State what we hold in direct, active, present-tense sentences.

- _The Great Game has begun._

What we write is our [[Current Best Understanding]]. Where we do not know, we say so just as plainly ([[We Do Not Know]]). We do not hedge each sentence, and we avoid words such as _always_, _never_ and _only_ where they claim more than we know.

## Urgency without fear

The stakes are real. The voice names what is at stake and what can be done, and it does not frighten or manipulate.

## The sacred and the practical together

Where it can, a passage holds both the larger [[Story]] and the next step: what to do today, this week, in this Circle.

## Formal, and warm

Write _it is_ rather than _it's_, and _have found_ rather than _'ve found_. Speak to the reader directly and with care, as to a fellow traveler.

## Return to the Goal

A passage bends back toward [[The Goal]]: helping one another, and all things, rise.

## Leave out the habits of machine writing

Writing that sounds machine-made loses the reader's trust. Leave out:

- an opening that talks about the passage before saying it (_Something miraculous happens when..._, _Here is how it works..._)
- the defensive pair (_This is not X. This is Y._)
- a doubt raised only to be knocked down (_Is this realistic?_)
- a closing line that only restates what was just said

## Voice and form

- Bold and [[Double Bracket]] a key concept the first time it appears in a passage, so that a reader scanning the page can see its structure.
- Use a header where the structure turns. If a header could be removed without changing the structure, remove it.
- Short, weighted lines are for moments of great emphasis. Used everywhere, they lose their weight.
- End a line with two spaces in verse and in sequences of standalone lines, such as bare wiki links and navigation footers, so the lines hold their shape. Prose paragraphs, lists and headers do not need them.

## The test

Read the paragraph aloud, and ask:

- Would a Circle reading this together feel that it is wise, right, true, and good. or would they want to skip ahead?
- Could someone in another country, or another century, receive it?
- Does it say the thing, or does it talk about the thing?

A paragraph that does not pass is not ready yet.

## What the voice is not

- The pulpit voice of any one religion.
- A corporate or brand voice.
- Academic prose.
- The voice of a marketer or an influencer.
- The self-help voice.
- The voice of an AI assistant.
## Companions

[[Our Way of Writing Here]] covers how we write and edit together.
