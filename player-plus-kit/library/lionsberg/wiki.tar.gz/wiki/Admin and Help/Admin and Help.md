# Admin and Help

This is where to come when you are lost, and where the wiki explains how it is written and kept. It is a jump page: a short table of contents to help you find your way.

## If you are lost

[[Help! I Am Lost]] shows how to get back to the start and how to find a page.

## How we wiki

- [[Our Way of Writing Here]]: how we write together, and how a change is proposed
- [[The LIØNSBERG Voice]]: how the shared body of work sounds
- [[Chunking]], [[Naming]] and [[Linking]]: how pages are divided, named and connected
- [[The Incipient Link]]: a link to a page that does not exist yet
- [[Why We Say Wiki Website Instead of Wiki]]

## Working in the wiki

- [[Getting the Wiki on Your Computer]]: your own copy, opened in Obsidian
- [[Obsidian Tips and Tricks]]: settings and plugins that make the work easier

## Records

- [[Import Log]]: what has been brought into this wiki, from where, and why
