# Obsidian Tips and Tricks

Settings and plugins that make working in the wiki easier. See [[Getting the Wiki on Your Computer]] for getting your copy and for pull and push.

## Core plugins we keep on

- **Files**
- **Search**
- **Quick switcher**
- **Backlinks**
- **Graph view**
- **Outline**
- **Note composer**
- **Command palette**
- **Bookmarks**
- **Word count**
- **File recovery**

## Community plugins worth having

_Remember to enable a plugin after installing it._

- **Find orphaned files and broken links**: useful as you build an information space
- **Page Heading From Links**: writes the header line for you when you create a page by following an incipient link
- **Git**: pull and push from inside Obsidian. It follows one repository per vault. When the vault is the folder above the wiki, set its **Custom base path** to `lionsberg-wiki`. Use its **Pull** command when you begin, and **Create backup with specific message** when you finish (newer versions may name this command differently). Save the page you are on first, or the push may miss your latest edits. If the plugin is overwhelmed by many changes at once, use Git in a terminal.

## Settings to check

### Editor

- **Default editing mode** = Live Preview
- **Readable line length** = off
- **Strict line breaks** = off
- **Show line numbers** = on

### Files and links

- **Automatically update internal links** = on, so that renaming a page repairs the links to it
- **Default location for new notes** = Same folder as current file, so that a page made by following a link lands inside the wiki
- **Default location for new attachments** = In the folder specified below
- **Attachment folder path** = `lionsberg-wiki/_attachments`

### Appearance

- **Base color scheme** = your preference
- **Show inline title** = off, so that the page's own first header is its only title
