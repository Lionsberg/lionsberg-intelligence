# The Inheritance

If The Story of LIØNSBERG is True,
Earth is neither the first nor the last world to face a crisis
in which the Old systems born of a mind virus collapse
and a New Civilization must be imagined, designed, and built.

We are not starting from scratch.
We are simply remembering the Divine Blueprints
and bringing the Highest Intention into Reality,
right here and now, in our own lives and worlds.

The wisdom and knowledge present in the LIØNSBERG Commons  
is offered freely, from the commons to the commons,
as part of our collective inheritance.  
It grows as we play The Great Game.  

Because it would take many years, if not lifetimes,
to read and comprehend it all,
an advanced AI Supersuit has been created
to supercharge co-creation among players of The Game.  
