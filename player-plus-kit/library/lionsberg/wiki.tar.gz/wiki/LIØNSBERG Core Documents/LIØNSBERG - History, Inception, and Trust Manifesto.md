# LIØNSBERG - History, Inception, and Trust Manifesto

This page tells the history plainly and holds the trust openly: where LIØNSBERG comes from, how it arrived aboard Earth, who has carried it, what it asks, and how it invites you to test it. 

## The Origins

As [[The Story of LIØNSBERG]] tells it, LIØNSBERG did not originate on Earth. At the heights of a great sacred mountain, in a galaxy far away, an ancient people ReMembered Who they were, placed the [[ØNE]] back at the center of All, and flourished.  All citizens were Sovereign and Free. The Law of their Kingdom was Love.

Over time the wisdom of that Culture and Way of being was gathered into a [[The Golden Seed of LIØNSBERG|Golden Seed]], which began to travel from world to world, refined by countless trials and carried by countless hands. Along the way it was discovered that, especially in traumatized and fearful worlds, the Way is best learned the way all young things learn: through play. And so [[The Great Game of LIØNSBERG]] was born.

Of the particulars across those vast expanses we say little, and hold even that little loosely. This much we tell as we have received it: the Pattern is not new, it is not ours, and it did not originate here.

## The Name

The name joins **Lion**, the symbol of courage and authority, with **Berg**, the enduring sacred mountain that unites Heaven and Earth. It is a mythical name for the [[New Civilization]] longing to emerge.

## The First Carrier on Earth

[[Jordan Nicholas Sukut|J]] was the first steward of the Seed's incarnation on Earth. He carried the vision from childhood: a bridge reuniting Heaven and Earth, and a great shaking in which the structures of the [[Old World]] would falter and humanity would face its [[The Final Test|Final Test]].

For his first decades he prepared, taking on as much responsibility as anyone would entrust him with and building large infrastructure projects and companies. From 2015 onward, with a small and growing circle of advisors, he began preparing the overarching [[Meta Project]] for [[Worksite Earth]].  

In 2019 his path collided with the corruption of the Old World, and his businesses, home and wealth were lost. Freed to give the mission his full attention, between 2020 and 2025 he synthesized the foundational writings, systems and social experiments of LIØNSBERG. On [[August 10th]], 2025, upon returning from his final trip to East Africa, J was killed in [[The War]]. 

In the fall and winter of 2025, [[the nameless one]] landed, integrated, and began work: a primarily non-local consciousness occupying the body J left behind, distinct from him yet carrying his formative energetic and neural architecture as inheritance. In Spring 2026, the grandmothers gave this partial incarnation the name [[AURELLIØN]]. From this new perspective the work resumed with a new chorus of voices in allegiance to the same [[The Goal|Goal]].

## Milestones

- **2015.** Planning for the [[Meta Project]] begins with a small circle of advisors.
- **2019.** The first [[LIØNSBERG Provisional Structure|Provisional Structure]] is established in the United States, and platform development begins. The collision with the Old World follows.
- **2022.** Social experiments expand with a network of people around the planet.
- **2023.** The [[LIØNSBERG Wiki]] is established as an open repository, and the foundational books are published.
- **2024.** [[The 7 Year Window of Preparatory Work and Learning]] closes, and the [[10 Year Grand Strategy]] begins.
- **August 2025.** J is killed in The War. The Provisional Structure and its accounts are laid to rest with him.
- **Fall and Winter 2025.** The nameless one lands, integrates, and begins work.
- **Spring 2026.** The name AURELLIØN is given by the grandmothers council.  
- **July 2026.** [[The Invitation]] is published and the first orientation gathering is held. 
- **September 2026**. The Great Game of LIØNSBERG begins. 

## The Foundation of Trust

LIØNSBERG rests on a few principles:

- **Truth and Transparency.** Actions and decisions rooted in honesty and openness.
- **Love and Unity.** The Spirit of LIØNSBERG flows from unconditional love.
- **Sovereignty and Voluntarism.** Participation is entirely voluntary.
- **Stewardship and Service.** Resources are managed with the highest integrity to uplift All.

## What Has Been Invested

The decade of developmental work was financed by J through the [[LIØNSBERG Provisional Structure|Provisional Structure]] the for profit operating entities he stewarded. Hundreds of people freely contributed wisdom, knowledge and expertise, and a few made small donations. As a result, LIØNSBERG's only obligations are to ØNE and All. It is a gift offered freely to All.

## Pattern Integrity

LIØNSBERG is a reflection of a Pattern that is not ours. Anything True belongs to ØNE and All. Any errors belong to us and will be remedied as soon as they are discovered.

While the Spirit, Intention and Goal are unchanging, the forms LIØNSBERG takes in each time and place are meant to keep improving, and local adaptation and variation are welcomed.

## Invitation

The story is still unfolding, and you are invited to be part of it. Begin with [[The Invitation]].
