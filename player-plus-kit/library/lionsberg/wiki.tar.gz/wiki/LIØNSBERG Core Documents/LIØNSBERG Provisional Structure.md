# LIØNSBERG Provisional Structure

LIØNSBERG is an unincorporated voluntary spiritual association co-operating towards [[The Goal]]. 

This holofractal "association of associations" is cosmic in scale, not Earth or human centric, and therefore *inherently and by definition* supranational and prior to any human or political authority.

The legal and organizational forms that LIØNSBERG creates to interface with any given world or jurisdiction are not what LIØNSBERG is. The spiritual association is universally true. The forms are provisional and designed to evolve: they are taken up when and where they serve, adapted as conditions change, and set down when they no longer serve.

## The Design at Planetary Scale

At planetary scale, the DNA of LIØNSBERG is a federated network of billions of holonic entities: one for every individual, [[Circle]], organization, and community in the [[Holofractal Omnifederation|Omnifederation]]. Each assumes the wise right structure over time.

Each individual and each cell of the emerging body structures itself according to its role, its mission, and the jurisdictions in which it works. Shared legal infrastructure enables this emergence and provides the interfaces with the [[Old World]].

## The Cascade

The structure cascades from the universal to the particular. Each level carries the same DNA and differentiates according to its role.

### Before any legal structure

1. **[[ØNE]].** From ØNE, in service of [[All]], LIØNSBERG exists and flows.
2. **The underlying unity.** All beings are already members of one living whole. This is true whether or not it is recognized.
3. **The right and responsibility to associate.** Sovereign individuals, groups, and localities hold the Divine right and moral responsibility to associate voluntarily in order to bring the [[Creator's Intent]] into reality.
4. **The spiritual association.** From that voluntary association, LIØNSBERG emerges in any domain as a private sovereign spiritual body with all attendant rights and protections. It is an incarnation of a pattern already operative beyond Earth. It is superordinate to any spatiotemporal authority, and it and its constituent elements are sovereign and free to self-organize and self-govern.
5. **Sovereign self-governing bodies.** Individuals in voluntary association form [[Self-Governing, Self-Sustaining, and Self-Replicating]] circles, cells, teams, organizations, communities, ecoregions, bioregions, etc.
6. **A shared identity and an open invitation.** LIØNSBERG is a shared identity that its co-creators may use to name what they instantiate. It is also an invitation to each inhabitant of a domain to take up an equal [[New Citizenship]] in the [[New Civilization]].

Everything above exists before any legal structure, on the basis of spiritual resonance, voluntary association, culture, and self-governance. This protects the sovereignty and independence of those collaborating, and it ensures that there is no overly centralized node or dependency that, if attacked or compromised, could bring down the Whole. Every legal form that follows is a tool and a support for the sovereigns who co-operate it.

### Legal and organizational forms

7. **Interfaces.** Where it serves, those associating in a given jurisdiction instantiate legal and governance infrastructure to interface with the existing political and legal systems and to accomplish their goals.
8. **Shared legal infrastructure.** The primary legal and governance commons established in a domain act as "Mother Trees". They resource and support the emergence of a decentralized array of self-governing, self-sustaining, and self-replicating entities, each with its own lifecycle and evolutionary trajectory.
9. **Differentiation.** Each hub, commons, organization, and federation chooses the locally and culturally appropriate legal forms that most faithfully reflect the Vision, Principles, and Values in its own domain.
10. **Federation.** Over time, conceptually similar yet locally fitted structures are established polycentrically around the planet. They are connected so that resources, information, and ideas can be exchanged voluntarily between all levels and localities towards the realization of [[ØNE Cosmic Commons]]. 

## In a Collapse-Ascension Nexus

In scenarios like [[The Collapse-Ascension Nexus]], most of the [[Old]] forms and accounts can be expected to collapse along with the old system they interface with.

The cascade is designed for this. The upper levels do not depend on the lower. When a legal form or an account fails, the association, its Circles, and its commons of knowledge remain, and new forms can be taken up where they are needed.

## The End Design

The end design is omnifederation: the realization of the underlying unity that already is, as one planetary commons within one cosmic commons.

The proposed constitutional articulation for Earth is the [[The Superorganism - Invitation and Request for Guidance|Invitation and Request for Guidance]], with its companions the [[Guidebook for the Emergence]] and [[The 12 Big Ideas]].

## The First Provisional Structure

The first shared legal infrastructure was established in the United States. Drawing on examples such as Mondragon, Switzerland, and the United States, it was designed as a blended ecosystem of for-profit and non-profit entities, of the kind each bioregion and locality requires in order to flourish. The diagram shows its configuration.

![[LIØNSBERG diagram 8-15-22.png]]

A higher resolution copy: [[LIØNSBERG Diagram 8-15-22.pdf]]

The diagram reads from the ground up:

- **Community.** The private voluntary LIØNSBERG Community and Federation, united by timeless and universal Intention, Values, Goals, and Constitution, with numerous local, national, and regional instantiations.
- **Stewardship.** A commons for social outreach, human development, and community development, with fiscal sponsorship, funds, and partner organizations around it.
- **Endowment.** A holding company that stewards a emerging family of enterprises, with leadership, management, and profit sharing.
- **Connection.** The interfaces with the wider world: contracts for services, socially aware capital, joint ventures, partner organizations, and projects.

This structure was approved in January 2019 and served through [[The 7 Year Window of Preparatory Work and Learning]], complying with the [[Existing Order]] as far as it could. It fell dormant upon J's death in 2025. It can can be revived if useful. 

From 2026 onward, investments and flows move through the decentralized structures self-organized by those playing [[The Great Game of LIØNSBERG]].

The learnings from Mondragon that informed the design are summarized in [[The Prophesy of Mondragon]].
