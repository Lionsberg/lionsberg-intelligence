# LIØNSBERG Context

In a moment of [[Meta Crisis]], We the People of Goodwill are voluntarily arising and uniting to accomplish [[The Goal]].

____  
An entry in [[LIØNSBERG Core Statements]]  
