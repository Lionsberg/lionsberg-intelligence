# LIØNSBERG Process

Our process is to progressively connect and empower a superorganism / federation to realize [[The Goal]].   

It is a [[Tipping Point Strategy]] rooted in a [[Shift In Spirit, Consciousness, and Paradigm]], starting with [[The First Three Percent]].

____  
An entry in [[LIØNSBERG Core Statements]]  
