# LIØNSBERG Spirit

The **[[Central Animating Spirit]]** of **[[LIØNSBERG]]** is [[ØNE]]. 

____  
An entry in [[LIØNSBERG Core Statements]]  
