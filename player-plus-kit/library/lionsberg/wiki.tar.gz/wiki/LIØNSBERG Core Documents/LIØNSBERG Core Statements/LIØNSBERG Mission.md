# LIØNSBERG Mission

The Mission of **[[LIØNSBERG]]** is to co-create **[[Heaven]]** everywhere for everyone.

The next milestone on this sacred mission and [[Critical Path]] is to connect and empower **[[The First Three Percent]]**.

____  
An entry in [[LIØNSBERG Core Statements]]  
