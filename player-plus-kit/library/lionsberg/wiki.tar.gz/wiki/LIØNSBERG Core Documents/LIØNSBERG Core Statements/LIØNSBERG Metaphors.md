# LIØNSBERG Metaphors

LIØNSBERG is like...

## 1.

...a Mythical Name for the [[New World]] we are [[Co-Creating]].  

## 2.

...an Ark purpose-built to carry us [[FROM the Old TO the New]]  

## 3.

...a Sacred Tree emerging from [[The Golden Seed]].  
[[The Sacred Tree]]  

See also [[The LIØNSBERG Book of Metaphors]]

____  
An entry in [[LIØNSBERG Core Statements]]  
