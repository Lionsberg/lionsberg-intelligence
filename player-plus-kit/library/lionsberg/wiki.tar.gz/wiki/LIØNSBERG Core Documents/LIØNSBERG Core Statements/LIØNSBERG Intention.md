# LIØNSBERG Intention

The intention of **[[LIØNSBERG]]** is the [[Creator's Intent]]—[[On Earth As it Is In Heaven]].

____  
An entry in [[LIØNSBERG Core Statements]]  
