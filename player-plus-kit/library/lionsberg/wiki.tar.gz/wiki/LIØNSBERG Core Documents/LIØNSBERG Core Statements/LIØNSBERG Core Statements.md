# LIØNSBERG Core Statements

[[One Sentence]]  
[[LIØNSBERG Context]]  
[[LIØNSBERG Intention]]  
[[LIØNSBERG Spirit]]  
[[LIØNSBERG Mission]]  
[[LIØNSBERG Vision]]  
[[LIØNSBERG Goal]]  
[[LIØNSBERG Values]]  
[[LIØNSBERG Process]]  
[[LIØNSBERG Personality]]  
[[LIØNSBERG Metaphors]]  